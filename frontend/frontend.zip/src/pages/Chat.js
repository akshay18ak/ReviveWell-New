import React, { useState, useEffect, useRef } from 'react';
import {
  Container,
  Paper,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  Typography,
  Divider,
  Box,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const Chat = () => {
  const { userId } = useParams();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [error, setError] = useState('');
  const messagesEndRef = useRef(null);
  const user = JSON.parse(localStorage.getItem('user'));

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    fetchMessages();
    scrollToBottom();
  }, [userId]);

  const fetchMessages = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `http://localhost:5000/chat/messages/${userId || 'ai'}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setMessages(response.data);
    } catch (err) {
      setError('Failed to load messages');
    }
  };

  const handleSend = async () => {
    if (!newMessage.trim()) return;

    try {
      const token = localStorage.getItem('token');
      let endpoint = userId 
        ? `http://localhost:5000/chat/send/${userId}`
        : 'http://localhost:5000/chat/ai-support';

      const response = await axios.post(
        endpoint,
        { message: newMessage },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      // Add the new message to the chat
      const messageObj = {
        id: Date.now(),
        sender_id: user.id,
        message: newMessage,
        timestamp: new Date().toISOString(),
      };

      if (response.data.message) {
        // Add AI/recipient response
        const responseObj = {
          id: Date.now() + 1,
          sender_id: userId || null, // null for AI
          message: response.data.message,
          timestamp: response.data.timestamp,
        };
        setMessages([...messages, messageObj, responseObj]);
      } else {
        setMessages([...messages, messageObj]);
      }

      setNewMessage('');
      setTimeout(scrollToBottom, 100);
    } catch (err) {
      setError('Failed to send message');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Container maxWidth="md" className="chat-container">
      <Paper elevation={3} sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <Box className="message-list" sx={{ flexGrow: 1, overflow: 'auto' }}>
          <List>
            {messages.map((message) => (
              <React.Fragment key={message.id}>
                <ListItem
                  sx={{
                    flexDirection: 'column',
                    alignItems: message.sender_id === user.id ? 'flex-end' : 'flex-start',
                  }}
                >
                  <Box
                    sx={{
                      maxWidth: '70%',
                      backgroundColor: message.sender_id === user.id ? '#1976d2' : '#f5f5f5',
                      color: message.sender_id === user.id ? 'white' : 'black',
                      padding: '10px 15px',
                      borderRadius: '15px',
                      marginBottom: '5px',
                    }}
                  >
                    <Typography>{message.message}</Typography>
                  </Box>
                  <Typography variant="caption" color="textSecondary">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </Typography>
                </ListItem>
                <Divider variant="middle" />
              </React.Fragment>
            ))}
            <div ref={messagesEndRef} />
          </List>
        </Box>

        <Box className="message-input" sx={{ p: 2, backgroundColor: 'background.paper' }}>
          {error && (
            <Typography color="error" sx={{ mb: 1 }}>
              {error}
            </Typography>
          )}
          <Box sx={{ display: 'flex', gap: 1 }}>
            <TextField
              fullWidth
              multiline
              maxRows={4}
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              variant="outlined"
              size="small"
            />
            <Button
              variant="contained"
              color="primary"
              endIcon={<SendIcon />}
              onClick={handleSend}
              disabled={!newMessage.trim()}
            >
              Send
            </Button>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
};

export default Chat;
