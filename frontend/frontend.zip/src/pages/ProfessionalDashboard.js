import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Divider,
  Button,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import PersonIcon from '@mui/icons-material/Person';

const ProfessionalDashboard = () => {
  const navigate = useNavigate();
  const [patients, setPatients] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        const config = {
          headers: { Authorization: `Bearer ${token}` }
        };

        // Fetch patients and appointments
        const [patientsRes, appointmentsRes] = await Promise.all([
          axios.get('http://localhost:5000/professional/patients', config),
          axios.get('http://localhost:5000/professional/appointments', config)
        ]);

        setPatients(patientsRes.data);
        setAppointments(appointmentsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleChatWithPatient = (patientId) => {
    navigate(`/chat/${patientId}`);
  };

  return (
    <Container className="dashboard-container">
      <Typography variant="h4" gutterBottom>
        Welcome Dr. {user.lastName}
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Your Patients
              </Typography>
              <List>
                {patients.map((patient) => (
                  <React.Fragment key={patient.id}>
                    <ListItem>
                      <ListItemAvatar>
                        <Avatar>
                          <PersonIcon />
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={`${patient.firstName} ${patient.lastName}`}
                        secondary={`Last Assessment: ${patient.lastAssessmentDate || 'Not taken'}`}
                      />
                      <Button
                        variant="outlined"
                        size="small"
                        onClick={() => handleChatWithPatient(patient.id)}
                      >
                        Chat
                      </Button>
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Upcoming Appointments
              </Typography>
              <List>
                {appointments.map((appointment) => (
                  <React.Fragment key={appointment.id}>
                    <ListItem>
                      <ListItemText
                        primary={`${appointment.patientName}`}
                        secondary={`Date: ${new Date(appointment.date).toLocaleDateString()}`}
                      />
                      <Button
                        variant="outlined"
                        size="small"
                        onClick={() => handleChatWithPatient(appointment.patientId)}
                      >
                        Chat
                      </Button>
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ProfessionalDashboard;
