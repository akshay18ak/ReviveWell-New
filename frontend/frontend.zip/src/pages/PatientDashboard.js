import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  List,
  ListItem,
  ListItemText,
  Divider,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const PatientDashboard = () => {
  const navigate = useNavigate();
  const [assessments, setAssessments] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        const config = {
          headers: { Authorization: `Bearer ${token}` }
        };

        // Fetch assessments and appointments
        const [assessmentsRes, appointmentsRes] = await Promise.all([
          axios.get('http://localhost:5000/assessment/history', config),
          axios.get('http://localhost:5000/patient/appointments', config)
        ]);

        setAssessments(assessmentsRes.data);
        setAppointments(appointmentsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <Container className="dashboard-container">
      <Typography variant="h4" gutterBottom>
        Welcome back, {user.firstName}!
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Assessments
              </Typography>
              <List>
                {assessments.slice(0, 5).map((assessment) => (
                  <React.Fragment key={assessment.id}>
                    <ListItem>
                      <ListItemText
                        primary={new Date(assessment.date).toLocaleDateString()}
                        secondary={`Score: ${assessment.score}`}
                      />
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate('/assessment')}
                sx={{ mt: 2 }}
              >
                Take New Assessment
              </Button>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Upcoming Appointments
              </Typography>
              <List>
                {appointments.slice(0, 5).map((appointment) => (
                  <React.Fragment key={appointment.id}>
                    <ListItem>
                      <ListItemText
                        primary={new Date(appointment.date).toLocaleDateString()}
                        secondary={`With: Dr. ${appointment.professionalName}`}
                      />
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
              <Button
                variant="contained"
                color="primary"
                onClick={() => navigate('/chat')}
                sx={{ mt: 2 }}
              >
                Chat with Professional
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default PatientDashboard;
