import React, { useState } from 'react';
import {
  Container,
  Card,
  CardContent,
  Typography,
  RadioGroup,
  FormControlLabel,
  Radio,
  Button,
  Stepper,
  Step,
  StepLabel,
  Alert,
} from '@mui/material';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const questions = [
  {
    id: 1,
    text: "How would you rate your current stress level?",
    options: [
      { value: 1, label: "Very Low" },
      { value: 2, label: "Low" },
      { value: 3, label: "Moderate" },
      { value: 4, label: "High" },
      { value: 5, label: "Very High" },
    ],
  },
  {
    id: 2,
    text: "How strong is your urge to use substances today?",
    options: [
      { value: 1, label: "No Urge" },
      { value: 2, label: "Mild Urge" },
      { value: 3, label: "Moderate Urge" },
      { value: 4, label: "Strong Urge" },
      { value: 5, label: "Very Strong Urge" },
    ],
  },
  {
    id: 3,
    text: "How well are you sleeping?",
    options: [
      { value: 5, label: "Very Well" },
      { value: 4, label: "Well" },
      { value: 3, label: "Moderately" },
      { value: 2, label: "Poorly" },
      { value: 1, label: "Very Poorly" },
    ],
  },
  // Add more questions as needed
];

const Assessment = () => {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const [error, setError] = useState('');

  const handleAnswer = (value) => {
    setAnswers({
      ...answers,
      [questions[activeStep].id]: value,
    });
  };

  const handleNext = () => {
    if (!answers[questions[activeStep].id]) {
      setError('Please select an answer before continuing');
      return;
    }
    setError('');
    setActiveStep((prev) => prev + 1);
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
    setError('');
  };

  const handleSubmit = async () => {
    try {
      const token = localStorage.getItem('token');
      const formattedAnswers = {
        stress_level: answers[1],
        substance_urge: answers[2],
        sleep_quality: answers[3]
      };
      
      await axios.post(
        'http://localhost:5000/assessment/submit',
        formattedAnswers,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      navigate('/patient-dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit assessment');
    }
  };

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom align="center">
        Daily Assessment
      </Typography>

      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {questions.map((_, index) => (
          <Step key={index}>
            <StepLabel></StepLabel>
          </Step>
        ))}
      </Stepper>

      {activeStep === questions.length ? (
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Assessment Complete
            </Typography>
            <Typography paragraph>
              Thank you for completing your daily assessment. Your responses help us provide better support.
            </Typography>
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              fullWidth
            >
              Submit Assessment
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent>
            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            <Typography variant="h6" gutterBottom>
              {questions[activeStep].text}
            </Typography>
            <RadioGroup
              value={answers[questions[activeStep].id] || ''}
              onChange={(e) => handleAnswer(parseInt(e.target.value))}
            >
              {questions[activeStep].options.map((option) => (
                <FormControlLabel
                  key={option.value}
                  value={option.value}
                  control={<Radio />}
                  label={option.label}
                />
              ))}
            </RadioGroup>
            <div style={{ marginTop: 20, display: 'flex', justifyContent: 'space-between' }}>
              <Button
                variant="outlined"
                onClick={handleBack}
                disabled={activeStep === 0}
              >
                Back
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={handleNext}
              >
                {activeStep === questions.length - 1 ? 'Finish' : 'Next'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </Container>
  );
};

export default Assessment;
